◈◈◈◈
class: Corruptant
title: Efflorescence of Decay
type: Elite Class
role: Mutation Controller | Terrain Warper
alignment: Corruptis + Vitalis
elements: [Venom, Serene]
tags: [mutation, terrain control, overgrowth, decay, transformation]
◈◈◈◈

# 🧪 Corruptant — Efflorescence of Decay  
*What grows in the rot is neither dead nor pure.* 🔱

> *“From the flesh of failure blooms the shape of what comes next.”* ⚜️

◈◈◈◈

**Summary**:  
The **Corruptant** is a bio-arcanist who manipulates organic terrain and spawns mutating fields of toxin-wreathed overgrowth. Functionally a **terrain controller and mutator**, the Corruptant shapes the battlefield with living, shifting hazards that alter movement, stats, and ecosystem behavior.

◈◈◈◈

## 🧩 Narrative Identity  
Corruptants represent a philosophy of inevitable change — that all things must rot to evolve. Their spells are overgrown gardens of decay, blooming with venom and thorns. They don’t fight with traditional magic, but through accelerated entropy and selective renewal. They are nature’s corrupted surgeons.

◈◈◈◈

## 📘 Tactical Role & Profile  

| Category        | Description                                       |
|----------------|----------------------------------------------------|
| **Archetype**   | Terrain Manipulator, Corruption Spreader           |
| **Combat Style**| Adaptive battlefield zoning, mutation layering     |
| **Weapons**     | All Caster Weapons — Harmful Magic, Helpful Magic, Ancient Magic
| **Elements**    | Venom, Serene                                      |
| **Alignment**   | ✴️ Corruptis + Vitalis                             |

◈◈◈◈

## 🧠 Behavior & Strengths  
- Creates **mutating growth zones** that evolve over time  
- Buffs allies inside while warping enemy stats (speed, resist, accuracy)  
- Causes corrupted roots to slow, snare, or poison  
- Excels in controlling chokepoints and map tempo  

◈◈◈◈

## 🔻 Weaknesses  
- Requires build-up time to reach optimal zone mutation  
- Weak in open, fast-moving fights  
- Zones can be bypassed with aerial or teleportation  
- Mutations are telegraphed, giving enemies time to adapt  

◈◈◈◈

## ✨ Ultimate — *Verdict Bloom*  
- Spawns a **monstrous flower** in a target area (lasts 12s)  
- Grows in three stages: Thornbed (slow), Pollencloud (confuse), Mawpetals (explosion)  
- Enemies caught in all 3 stages are afflicted with *Bio-Curse* — reducing all stats by 15%  
- Allies near it gain lifesteal and decay resistance  

◈◈◈◈

## 📊 Stat Allocation  

| Stat            | Value | Bar           |
|-----------------|--------|---------------|
| Health          | 6/10   | ██████░░░░     |
| Strength        | 3/10   | ███░░░░░░░     |
| Intelligence    | 8/10   | ████████░░     |
| Evasion         | 4/10   | ████░░░░░░     |
| Dexterity       | 5/10   | █████░░░░░     |
| Defense         | 6/10   | ██████░░░░     |
| Magic Resist    | 7/10   | ███████░░░     |
| Resolve         | 6/10   | ██████░░░░     |
| Spirit          | 7/10   | ███████░░░     |
| Ascension Gain  | 5/10   | █████░░░░░     |

◈◈◈◈

## 🧭 Disciplines

### 🜂 Discipline: Sporemind  
**Theme**: *Fungal intelligence and predictive defense*  
**Playstyle**: Sets up traps and spreading hazards  
**Identity**: Strategic zone-layering and control

Sample Mechanics:
- Pollenclouds linger and stack confusion chance  
- Can tether spores to allies for defensive reactions  
- Thornbed stage becomes immobilizing instead of slow  

◈◈◈◈

### 🜁 Discipline: Bloomlord  
**Theme**: *Evolved corruption and stat manipulation*  
**Playstyle**: Enhances mutation layers and personal buffs  
**Identity**: Hybrid disruptor with strong solo presence  

Sample Mechanics:
- Each active zone grants passive regen  
- Can “ripen” zones early for instant AoE burst  
- Grows a thornmail passive that reflects damage  

◈◈◈◈

### 🜃 Discipline: Mycoverse  
**Theme**: *Living network of corruption*  
**Playstyle**: Connects zones into intelligent terrain  
**Identity**: Advanced macro-level controller  

Sample Mechanics:
- Mutations spread across map slowly like mycelium  
- Enemies crossing infected terrain take stacking rot  
- Can teleport to any corrupted zone every 20s  

◈◈◈◈

[⬆️ Return to Index](/index.html)