◈◈◈◈
class: Phoenixborne
title: Ember Reclaimer
type: Elite Class
role: Resurrection DPS | Flame Utility
alignment: Vitalis + Primordis
elements: [Flame, Chaos]
tags: [revival, burst, self-ignite, fire, sacrifice]
◈◈◈◈

# Phoenixborne — Ember Reclaimer  
*That which dies in fire is born with purpose.* 🔱

> *“Ash remembers. Flame forgives.”* ⚜️

◈◈◈◈

**Summary**:  
The **Phoenixborne** is a volatile reclaimer of lost vitality — burning itself and allies alike to fuel a cycle of rebirth and escalation. Capable of death-triggered ultimates and burst-fire resurrection tactics, it thrives on *controlled sacrifice and tactical martyrdom*.

◈◈◈◈

## 🧩 Narrative Identity  
Phoenixborne are the architects of endings that lead to beginnings. They willingly step into ruin to ignite the pulse of something stronger — warriors of fire who trade their own demise for ascension and others' survival.

◈◈◈◈

## 📘 Tactical Role & Profile  

| Category        | Description                                |
|----------------|---------------------------------------------|
| **Archetype**   | Revive DPS, Explosive Sacrifice             |
| **Combat Style**| Firebomb surges, death triggers, ember fields|
| **Weapons**     | All Caster Weapons — Harmful Magic, Helpful Magic, Ancient Magic
| **Elements**    | Flame, Chaos                                |
| **Alignment**   | ✴️ Vitalis + Primordis                      |

◈◈◈◈

## 🧠 Behavior & Strengths  
- Revives once per fight with *Ashborn*  
- Emits flame zones that empower allies and burn enemies  
- Powerful burst when near death or reviving  
- Synergizes well with risky and aggressive comps  

◈◈◈◈

## 🔻 Weaknesses  
- Requires positioning and death timing  
- Weak to cleanse/dispel effects  
- Healing from allies can disrupt its optimal cycle  
- Low sustained DPS  

◈◈◈◈

## ✨ Ultimate — *Flare Reclamation*  
- Upon death, rebirths with full mana and triggers a fire nova  
- All allies gain health equal to 50% of the Phoenixborne's HP  
- Spawns *Ashflame Zones* that grant crit chance and ignite enemies  
- Usable only after falling once per encounter  

◈◈◈◈

## 📊 Stat Allocation  

| Stat            | Value | Bar           |
|-----------------|--------|---------------|
| Health          | 5/10   | █████░░░░░     |
| Strength        | 4/10   | ████░░░░░░     |
| Intelligence    | 8/10   | ████████░░     |
| Evasion         | 6/10   | ██████░░░░     |
| Dexterity       | 6/10   | ██████░░░░     |
| Defense         | 3/10   | ███░░░░░░░     |
| Magic Resist    | 5/10   | █████░░░░░     |
| Resolve         | 9/10   | █████████░     |
| Spirit          | 7/10   | ███████░░░     |
| Ascension Gain  | 4/10   | ████░░░░░░     |

◈◈◈◈

## 🧭 Disciplines

### 🜂 Discipline: Emberwake  
- Flame zones trail behind movement  
- Crits restore health  
- Can cast a spell while downed once per encounter  

◈◈◈◈

### 🜁 Discipline: Ashmantle  
- Becomes immune to burn effects  
- Ashborn revive grants bonus fire damage for 10s  
- Flame zones pulse healing to nearby allies  

◈◈◈◈

### 🜃 Discipline: Cinderchain  
- Burn stacks spread like a disease  
- Death explosion chains to all ignited targets  
- Ignite also weakens enemy healing  

◈◈◈◈

[⬆️ Return to Index](/index.html)