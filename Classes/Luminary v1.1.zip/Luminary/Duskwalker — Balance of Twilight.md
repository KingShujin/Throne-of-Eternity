◈◈◈◈
class: Duskwalker
title: Balance of Twilight
type: Elite Class
role: Dual-Aligned Tactician | Hybrid Shift Mage
alignment: Lunaris + Solaris
elements: [Frost, Shadow]
tags: [dual-state, equilibrium, light-dark, hybrid, tactician]
◈◈◈◈

# 🌒 Duskwalker — Balance of Twilight  
*Where shadow kisses light, a new path is born.* 🔱

> *"Neither dawn nor dusk claims me. I am the breath between."* ⚜️

◈◈◈◈

**Summary**:  
The **Duskwalker** walks the razor's edge of contradiction — manipulating radiant and umbral forces simultaneously to balance the battlefield. By alternating stances between **Sunveil** and **Moonshade**, the Duskwalker adapts fluidly to team needs and enemy behavior.

◈◈◈◈

## 🧩 Narrative Identity  
Duskwalkers are cosmological intermediaries — mystics of celestial tension. In a world pulled toward absolutes, they remain poised in the threshold. They are philosophical warriors who reject polarization, wielding radiant frost and shadowlight as symbols of unity and caution.

◈◈◈◈

## 📘 Tactical Role & Profile  

| Category        | Description                                        |
|----------------|-----------------------------------------------------|
| **Archetype**   | Adaptive Tactician, State-Shifting Mage             |
| **Combat Style**| Dual-mode casting, stance combos, twilight zones    |
| **Weapons**     | All Caster Weapons — Harmful Magic, Helpful Magic, Ancient Magic
| **Elements**    | Frost, Shadow                                       |
| **Alignment**   | ✴️ Lunaris + Solaris                                 |

◈◈◈◈

## 🧠 Behavior & Strengths  
- Switches between **Sunveil (light stance)** and **Moonshade (shadow stance)**  
- Each stance has distinct bonuses and ability variants  
- Controls midrange fights with frost pulses and radiant shadows  
- Excels in prolonged fights where timing and rotation mastery matter  

◈◈◈◈

## 🔻 Weaknesses  
- Stance-locking limits instant reactivity  
- Requires rhythm and predictive play  
- Cannot simultaneously use both stance powers  
- Weak to silence and displacement effects  

◈◈◈◈

## ✨ Ultimate — *Equinox Spiral*  
- Freezes the battlefield in a radiant eclipse for 8 seconds  
- Abilities now gain both **light** and **shadow** traits simultaneously  
- Enemies caught at center take damage and are slowed by 40%  
- Allies within gain increased healing received and cleanse on hit  

◈◈◈◈

## 📊 Stat Allocation  

| Stat            | Value | Bar           |
|-----------------|--------|---------------|
| Health          | 5/10   | █████░░░░░     |
| Strength        | 3/10   | ███░░░░░░░     |
| Intelligence    | 9/10   | █████████░     |
| Evasion         | 5/10   | █████░░░░░     |
| Dexterity       | 7/10   | ███████░░░     |
| Defense         | 4/10   | ████░░░░░░     |
| Magic Resist    | 6/10   | ██████░░░░     |
| Resolve         | 7/10   | ███████░░░     |
| Spirit          | 8/10   | ████████░░     |
| Ascension Gain  | 6/10   | ██████░░░░     |

◈◈◈◈

## 🧭 Disciplines

### 🜂 Discipline: Solstice Split  
**Theme**: *Precision stance swapping*  
**Playstyle**: Gains energy each time you switch stance mid-combo  
**Identity**: For dextrous, rhythm-based players

Sample Mechanics:
- Gain energy buff after each clean stance swap  
- "Twilight Crescendo" deals bonus damage if combo spans both stances  
- Gain mobility after switching stances mid-cast  

◈◈◈◈

### 🜁 Discipline: Veilkeeper  
**Theme**: *Celestial equilibrium and control*  
**Playstyle**: Enhances stance buffs and reduces penalties  
**Identity**: For strategic sustain/control builds  

Sample Mechanics:
- Reduced cooldown on stance switching  
- Buff durations extended by 2s  
- Twilight zones now heal allies and reduce enemy damage  

◈◈◈◈

### 🜃 Discipline: Eclipse Singularity  
**Theme**: *Merge light and dark into volatile singularities*  
**Playstyle**: Amplifies dual-element burst and AoE  
**Identity**: Offensive controller that plays for climax points  

Sample Mechanics:
- Combine light and shadow spells for explosive zone ruptures  
- Stance swap creates a pulse that silences enemies briefly  
- Ultimate duration extended by 3 seconds and gains damage component  

◈◈◈◈

[⬆️ Return to Index](/index.html)