◈◈◈◈
class: Luminary
title: Aurora of Benediction
type: Base Class
role: AoE Support | Aura Healer
alignment: Solaris + Vitalis
elements: [Serene, Sola]
tags: [healing, aura, radiant, support, sanctified]
◈◈◈◈

# Luminary — Aurora of Benediction  
*The dawnlight whose breath heals the world.* 🔱

> *"There is no storm my light cannot soften."* ⚜️

◈◈◈◈

**Summary**:  
The **Luminary** is a sanctified beacon who radiates healing auras and shields through ambient light. More than a healer, the Luminary is a walking sanctuary — a vessel of collective will and divine solar renewal.

◈◈◈◈

## 🧩 Narrative Identity  
Born from the twilight between devastation and dawn, the Luminary represents a covenant between survival and hope. They do not command light — they *become* it. Their presence alone fortifies resolve, and their glow purges both wounds and despair. In a world of ruin and shadows, Luminaries are temples in motion.

◈◈◈◈

## 📘 Tactical Role & Profile  

| Category        | Description                                       |
|----------------|----------------------------------------------------|
| **Archetype**   | Sustainer, Field Support                           |
| **Combat Style**| Aura casting, pulse-based healing, radiant bursts |
| **Weapons**     | All Caster Weapons — Harmful Magic, Helpful Magic, Ancient Magic
| **Elements**    | Serene, Sola                                       |
| **Alignment**   | ✴️ Solaris + Vitalis                               |

◈◈◈◈

## 🧠 Behavior & Strengths  
- Generates healing and shield auras around allies  
- Creates radiant zones that purify debuffs over time  
- Boosts nearby regeneration and elemental resistance  
- Gains Ascension faster near allies in need  

◈◈◈◈

## 🔻 Weaknesses  
- Weak solo performance  
- Vulnerable to silence or anti-healing debuffs  
- Telegraphed zone placement — requires allies to stay nearby  
- Low burst or reactive healing  

◈◈◈◈

## ✨ Ultimate — *Celestial Benediction*  
- Erects a **Sanctum of Light** that pulses healing to allies and weakens enemies inside  
- Lasts 12 seconds, emitting **solar waves** every 3s: heal + damage + cleanse  
- Allies within the sanctum gain "Dawnshield": blocks one incoming lethal strike  

◈◈◈◈

## 📊 Stat Allocation  

| Stat            | Value | Bar           |
|-----------------|--------|---------------|
| Health          | 6/10   | ██████░░░░     |
| Strength        | 2/10   | ██░░░░░░░░     |
| Intelligence    | 8/10   | ████████░░     |
| Evasion         | 3/10   | ███░░░░░░░     |
| Dexterity       | 3/10   | ███░░░░░░░     |
| Defense         | 4/10   | ████░░░░░░     |
| Magic Resist    | 6/10   | ██████░░░░     |
| Resolve         | 7/10   | ███████░░░     |
| Spirit          | 9/10   | █████████░     |
| Ascension Gain  | 7/10   | ███████░░░     |

◈◈◈◈

## 🧭 Disciplines

### 🜂 Discipline: Dawnbinder  
- Converts overhealing into temporary shields  
- "Solar Ward" reflects a portion of magic damage  
- Grants "Mercy Zone": allies near death become invulnerable for 1s  

◈◈◈◈

### 🜁 Discipline: Benedictionist  
- Extends duration of auras by 3s per target healed  
- Increases radius of all healing zones  
- Allies in auras gain resistance to crowd control  

◈◈◈◈

### 🜃 Discipline: Solstice Vow  
- Solar auras now damage enemies slightly  
- Cleansing effects dispel enemy boons in range  
- Ultimate adds a final burst of radiant judgment to enemies  

◈◈◈◈

[⬆️ Return to Index](/index.html)