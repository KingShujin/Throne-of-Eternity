◈◈◈◈
class: Ascended Luminary
title: Guiding Halo
type: Elite Class
role: Zone Guardian | Radiant Controller
alignment: Solaris + Sanctus
elements: [Sola, Energy]
tags: [aura, lightfield, control, sanctified, beacon]
◈◈◈◈

# 🌟 Ascended Luminary — Guiding Halo  
*The sovereign light that shapes the path ahead.* 🔱

> *“I do not walk behind you, nor before. I *am* the light beneath your every step.”* ⚜️

◈◈◈◈

**Summary**:  
The **Ascended Luminary** refines the raw benediction of the base class into **strategic lightfield dominion** — controlling space with radiant seals, divine lenses, and blessed ground. It turns the battlefield into a radiant puzzle where allies are emboldened and enemies eroded.

◈◈◈◈

## 🧩 Narrative Identity  
Ascended Luminaries are not worshippers — they are the *standard* by which worship is measured. They are both celestial compass and burning boundary, mediators of grace and discipline. Each step they take leaves a sigil, each word manifests a corridor of judgment and clarity. To oppose them is to be burned by precision, not fury.

◈◈◈◈

## 📘 Tactical Role & Profile  

| Category        | Description                                      |
|----------------|---------------------------------------------------|
| **Archetype**   | Zone Denial, Support-Controller                   |
| **Combat Style**| Strategic field placement, radiant effects        |
| **Weapons**     | All Caster Weapons — Harmful Magic, Helpful Magic, Ancient Magic
| **Elements**    | Sola, Energy                                      |
| **Alignment**   | ✴️ Solaris + Sanctus                              |

◈◈◈◈

## 🧠 Behavior & Strengths  
- Creates radiant *zones* that empower allies and slow enemies  
- Manipulates *line-of-sight and zone layering* with holy lenses  
- Stacks radiant fields for *layered cleansing or damage amplification*  
- Excels in sieges, hallways, and ritual defenses  

◈◈◈◈

## 🔻 Weaknesses  
- Loses effectiveness in fast-moving or scattered fights  
- Dependent on team positioning  
- Predictable when cornered — zones don’t move  
- Can be overrun if setup is denied  

◈◈◈◈

## ✨ Ultimate — *Prism of Revelation*  
- Places a **giant halo prism** at target location (10s duration)  
- Projects 5 rays of light in all directions — rotating every 2s  
- Enemies struck are revealed, slowed, and take radiant damage  
- Allies inside gain double healing and *True Vision* (can ignore stealth/invisibility)  

◈◈◈◈

## 📊 Stat Allocation  

| Stat            | Value | Bar           |
|-----------------|--------|---------------|
| Health          | 5/10   | █████░░░░░     |
| Strength        | 3/10   | ███░░░░░░░     |
| Intelligence    | 8/10   | ████████░░     |
| Evasion         | 2/10   | ██░░░░░░░░     |
| Dexterity       | 4/10   | ████░░░░░░     |
| Defense         | 6/10   | ██████░░░░     |
| Magic Resist    | 7/10   | ███████░░░     |
| Resolve         | 9/10   | █████████░     |
| Spirit          | 8/10   | ████████░░     |
| Ascension Gain  | 6/10   | ██████░░░░     |

◈◈◈◈

## 🧭 Disciplines

### 🜂 Discipline: Solar Cartograph  
**Theme**: *Light-map mastery*  
**Playstyle**: Precast radiant fields and walk allies into power zones  
**Identity**: Tactical players who treat battles like sanctified terrain

Sample Mechanics:
- Lightfields persist after movement  
- Can “stitch” zones together for chain effects  
- Enemies stepping over multiple zones take bonus radiant stacks  

◈◈◈◈

### 🜁 Discipline: Voice of the Sanctum  
**Theme**: *Holy command and protective dominance*  
**Playstyle**: Focused on empowering allies and blessing zones  
**Identity**: For guardians and commanders of formation

Sample Mechanics:
- Zones cleanse on entry and exit  
- Allies inside zones gain temporary Sanctified Buff  
- Can reposition one zone instantly every 20s  

◈◈◈◈

### 🜃 Discipline: Refracted Judgment  
**Theme**: *Splintered light as weapon*  
**Playstyle**: Focused on radiant shards, burn zones, and mirror punishments  
**Identity**: Offensive radiant controller

Sample Mechanics:
- Zones now pulse damage if overlapped  
- Can leave “radiant trails” when moving  
- Enemies damaged by 3 zones gain **Blind** and vulnerability  

◈◈◈◈

[⬆️ Return to Index](/index.html)