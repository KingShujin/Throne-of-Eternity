◈◈◈◈
class: Ruinvoker
title: Beacon of Collapse
type: Elite Class
role: DoT Controller | Corrosive Warlock
alignment: Nihilis + Corruptis
elements: [Chaos, Venom]
tags: [damage over time, decay, corruption, ruin, plague]
◈◈◈◈

# 💀 Ruinvoker — Beacon of Collapse  
*That which cannot break will rot.* 🔱

> *“I do not bring death. I teach the world how to end itself.”* ⚜️

◈◈◈◈

**Summary**:  
The **Ruinvoker** is a master of decay magic — weaving entropy into virulent fields, soul-sapping sigils, and creeping infestations. A hybrid **damage-over-time controller**, the Ruinvoker excels at softening entire enemy lines through **rot, ruin, and refusal to let anything remain whole**.

◈◈◈◈

## 🧩 Narrative Identity  
Ruinvokers are not villains — they are inevitabilities. Manifesting the world’s corruption back upon itself, they believe the cycle of endings is sacred. Each cast is a whispered entropy, each plague a promise that nothing built without purpose will last.

◈◈◈◈

## 📘 Tactical Role & Profile  

| Category        | Description                                       |
|----------------|----------------------------------------------------|
| **Archetype**   | Damage-over-Time, Debuff Specialist                |
| **Combat Style**| Infection zones, rot pulses, affliction stacking  |
| **Weapons**     | All Caster Weapons — Harmful Magic, Helpful Magic, Ancient Magic
| **Elements**    | Chaos, Venom                                       |
| **Alignment**   | ✴️ Nihilis + Corruptis                             |

◈◈◈◈

## 🧠 Behavior & Strengths  
- Spreads rot and debuffs through enemies over time  
- Creates contagious **Ruin Zones** that grow with each victim  
- Reduces healing and defense on afflicted targets  
- Excellent in siege, attrition, and erosion-based tactics  

◈◈◈◈

## 🔻 Weaknesses  
- Low burst potential — requires time to scale  
- Weak to cleanse-heavy compositions  
- Poor synergy with high-mobility teams  
- Vulnerable while setting up zones or sigils  

◈◈◈◈

## ✨ Ultimate — *Collapse Engine*  
- Unleashes a creeping **Ruin Engine** over a large area (lasts 10s)  
- Spawns rot-spikes every 2s that deal Venom and Chaos damage  
- All enemies inside gain “Fragile” — 20% reduced healing, and explode on death for AoE DoT  
- Spikes remain for 8s after duration ends  

◈◈◈◈

## 📊 Stat Allocation  

| Stat            | Value | Bar           |
|-----------------|--------|---------------|
| Health          | 4/10   | ████░░░░░░     |
| Strength        | 2/10   | ██░░░░░░░░     |
| Intelligence    | 9/10   | █████████░     |
| Evasion         | 3/10   | ███░░░░░░░     |
| Dexterity       | 4/10   | ████░░░░░░     |
| Defense         | 3/10   | ███░░░░░░░     |
| Magic Resist    | 5/10   | █████░░░░░     |
| Resolve         | 7/10   | ███████░░░     |
| Spirit          | 8/10   | ████████░░     |
| Ascension Gain  | 6/10   | ██████░░░░     |

◈◈◈◈

## 🧭 Disciplines

### 🜂 Discipline: Pestilent Doctrine  
**Theme**: *Relentless spread and infection*  
**Playstyle**: Focuses on multiplying DoT effects  
**Identity**: Designed for zone rot-maximizers

Sample Mechanics:
- Afflicted targets infect others nearby on death  
- DoT durations extended by 25%  
- Ruin Zones can leap to new locations every 8s  

◈◈◈◈

### 🜁 Discipline: Carrion Covenant  
**Theme**: *Ruin as power and sacrifice*  
**Playstyle**: Gains strength as enemies decay  
**Identity**: For players who thrive on controlled decline

Sample Mechanics:
- Gains buffs per enemy afflicted beyond 10s  
- Can consume DoTs to detonate them early  
- Healing received is halved, but deals more damage when low  

◈◈◈◈

### 🜃 Discipline: Black Bloom  
**Theme**: *Beauty in rot, surreal decay*  
**Playstyle**: Visualizes decay fields as cursed artforms  
**Identity**: For expressive AoE controllers

Sample Mechanics:
- Rot Zones pulse rhythmically and distort space  
- Allies inside zones gain “Decayed Grace”: dodge bonus  
- Final tick of all DoTs deals double damage and applies slow  

◈◈◈◈

[⬆️ Return to Index](/index.html)